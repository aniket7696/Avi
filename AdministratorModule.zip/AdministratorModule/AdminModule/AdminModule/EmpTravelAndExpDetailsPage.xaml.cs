﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AdminModule
{
    /// <summary>
    /// Interaction logic for EmpTravelAndExpDetailsPage.xaml
    /// </summary>
    public partial class EmpTravelAndExpDetailsPage : Window
    {
        public EmpTravelAndExpDetailsPage()
        {
            InitializeComponent();
        }

        private void BtnShowTravelDetails_Click(object sender, RoutedEventArgs e)
        {
            Admin_TravelExpense.Navigate(new TravelDetailsView());
        }

        private void BtnShowExpenseReport_Click(object sender, RoutedEventArgs e)
        {
            Admin_TravelExpense.Navigate(new ExpenseReportView());
        }
    }
}
