﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab12_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter File name with complete path.");
            string strFileName = Console.ReadLine();
            FileStream filestream1 = new FileStream(strFileName, FileMode.CreateNew, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(filestream1);
            streamWriter.WriteLine("this is a Test");
            streamWriter.WriteLine("this is a Test");
            streamWriter.WriteLine("this is a Test");
            streamWriter.Flush();
            streamWriter.Close();
            filestream1.Close();

            FileStream fileStream2 = new FileStream(strFileName, FileMode.Open, FileAccess.Read);
            StreamReader streamReader = new StreamReader(fileStream2);
            int ch = streamReader.Read();
            while (ch > 0)
            {
                Console.Write((char)ch);
                ch = streamReader.Read();
            }
            streamReader.Read();
            streamReader.Close();
            fileStream2.Close();

            Console.ReadKey();
        }
    }
}
