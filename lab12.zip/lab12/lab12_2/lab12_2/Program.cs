﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab12_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceDir = @"C:\Users\hemangjo\Desktop\assignment 2";
            string backupDir = @"C:\Users\hemangjo\Desktop\assignment 2\lab12";

            try
            {
                
                string[] txtList = Directory.GetFiles(sourceDir, "*.txt");

                
                // Copy text files.
                foreach (string f in txtList)
                {

                    // Remove path from the file name.
                    string fName = f.Substring(sourceDir.Length + 1);

                    try
                    {
                        // Will not overwrite if the destination file already exists.
                        File.Copy(Path.Combine(sourceDir, fName), Path.Combine(backupDir, fName));
                    }

                    // Catch exception if the file was already copied.
                    catch (IOException copyError)
                    {
                        Console.WriteLine(copyError.Message);
                    }
                }

               
                
            }

            catch (DirectoryNotFoundException dirNotFound)
            {
                Console.WriteLine(dirNotFound.Message);
            }
        }
    }
}
