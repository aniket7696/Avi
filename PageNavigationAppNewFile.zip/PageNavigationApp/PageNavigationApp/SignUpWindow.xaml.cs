﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            
                this.Hide();
                //code to authenticate user
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();

           
        }

        //to clear all text of controls
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {

            foreach (UIElement control in gridSignUp.Children)
            {
                if (control.GetType() == typeof(TextBox))
                {
                    TextBox txtBox = (TextBox)control;

                    txtBox.Text = null;
                }
                if (control.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)control;

                    cmbBox.Text = null;
                }
            }
            //txtFirstName.Clear();
            //txtMiddName.Clear();
            //txtLastName.Clear();
            //txtPassword.Clear();
            //txtCnfPwd.Clear();
            //txtUserId.Clear();
            //txtBankNo.Clear();
            //txtMobNo.Clear();
            cmbLocation.SelectedValue = null;
            
        }

        private void BtnAlreadyAcc_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            LoginWindow login = new LoginWindow();
            login.Show();
        }
    }
}
