﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for ForgatePassword.xaml
    /// </summary>
    public partial class ForgatePassword : Window
    {
        public ForgatePassword()
        {
            InitializeComponent();
        }

        private void BtnUpdatePassword_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCnfPassword.Password) && !string.IsNullOrEmpty(txtNewPassword.Password))
            {
                this.Hide();
                //code to authenticate user
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();

            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
           
                this.Hide();
                //code to authenticate user
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();

            
        }
    }
}
