﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOperations.Clibrary
{
    public class StringOperations
    {

        // Function Search a Character from string.
        public static int SearchPosition(string input, char seacrhCriteria)
        {
            int index = input.IndexOf(seacrhCriteria);
            return index;
        }
    }
}
