﻿//<Summary>
/*********************************************************************
 * File                 : DoctorMgmtSytemException.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement Doctor Management System
                          using layered Architecture.
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
//</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorMgmtSystem.Exceptions
{
    // Custom defined Excetion
    // Implementation Of ApplicationException

    public class DoctorMgmtSystemException : ApplicationException
    {

        public DoctorMgmtSystemException() : base()
        {

        }

        public DoctorMgmtSystemException(string message) : base(message)
        {

        }

        public DoctorMgmtSystemException(string message, Exception objEx) : base(message, objEx)
        {

        }

    }
}
