﻿//<Summary>
/*********************************************************************
 * File                 : DoctorDAL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement Doctor Management System
                          using layered Architecture.
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
//</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DoctorMgmtSystem.DataAccessLayer
{
    
    [Serializable]

    public class DoctorDAL
    {
        // List Creation to store the objects of Doctor Class

        public static List<Doctor> objDoctorList = new List<Doctor>();
        public static List<Doctor> objDoctorList1 = new List<Doctor>();

        // Function to all Doctor in the list

        public bool addDoctorDAL(Doctor objDoctor)
        {
            bool doctorAdded = false;

            try
            {
                objDoctorList.Add(objDoctor);
                doctorAdded = true;
            }

            catch (SystemException objEx)
            {
                throw new DoctorMgmtSystemException(objEx.Message);
            }

            return doctorAdded;
        }

        // Function to search a Doctor by Registration Number

        public Doctor searchDoctorDAL(int registration_No)
        {
            Doctor objDoctor = null;

            try
            {
                objDoctor = objDoctorList.Find(doc => doc.DoctRegistraionNumber.Equals(registration_No));
            }

            catch (Exception objEx)
            {
                throw new DoctorMgmtSystemException(objEx.Message);
            }

            return objDoctor;

        }

      
        // Function to list the Doctors
        public List<Doctor> getAllDoctorDAL()
        {
            return objDoctorList;
        }
    }
}
