﻿

select * from [airline].[Flights];

select * from [airline].[Reservation];
select * from [airline].[FlightClass]

select * from [airline].[Users];




create procedure [airline].[USP_Rev]
@f_Id int

AS

  Begin

     Select a.FlightID, a.NoofTickets , b.Class , b.Fare from [airline].[Reservation] a inner join [airline].[FlightClass] b on a.FlightID = b.FlightID;
 End

 EXEC [airline].[USP_Rev] 109; 