﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Revenue.Exceptions;
using Revenue.Entities;

namespace Revenue.BL
{
    public class RevenueBL
    {


    }
}
