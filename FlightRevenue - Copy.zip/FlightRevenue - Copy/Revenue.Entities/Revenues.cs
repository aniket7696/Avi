﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revenue.Entities
{
    public class Revenues
    {
        private int _fareOfBusinessClass;
        public int FareBusinessClass
        {
            get
            {
                return _fareOfBusinessClass;
            }
            set

            {
                _fareOfBusinessClass = value;
            }
        }

        private int _fareOfFirstClass;
        public int FareFirstClass
        {
            get
            {
                return _fareOfFirstClass;
            }
            set

            {
                _fareOfFirstClass = value;
            }
        }

        private int _fareOfEconomyClass;
        public int FareEconomyClass
        {
            get
            {
                return _fareOfEconomyClass;
            }
            set

            {
                _fareOfEconomyClass = value;
            }
        }


        private int _noOfBusinessClass;
        public int NumberBusinessClass
        {
            get
            {
                return _noOfBusinessClass;
            }
            set

            {
                _noOfBusinessClass = value;
            }
        }


        private int _noOfFirstClass;
        public int NumberFirstClass
        {
            get
            {
                return _noOfFirstClass;
            }
            set

            {
                _noOfFirstClass = value;
            }
        }

        private int _noOfEconomyClass;
        public int NumberEconomyClass
        {
            get
            {
                return _noOfEconomyClass;
            }
            set

            {
                _noOfEconomyClass = value;
            }
        }

    }
}
