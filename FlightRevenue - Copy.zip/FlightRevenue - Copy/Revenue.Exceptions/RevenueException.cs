﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revenue.Exceptions
{
    public class RevenueException : ApplicationException
    {
        public RevenueException() : base()
        { }

        public RevenueException(string message) : base(message)
        { }

        public RevenueException(string message, Exception exception) : base(message, exception)
        { }
    }


}
