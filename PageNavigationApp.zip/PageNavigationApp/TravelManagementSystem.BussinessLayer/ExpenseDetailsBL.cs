﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelManagementSystem.ExceptionClass;

namespace TravelManagementSystem.BussinessLayer
{
    public class ExpenseDetailsBL
    {
        Training_24Oct18_PuneEntities expDetailsDbContext = null;
        int MRNo;
        public ExpenseDetailsBL()
        {
            expDetailsDbContext = new Training_24Oct18_PuneEntities();
       }


        //Return Mr_Number for given employee ID
        public int MRNumberOfEmp(int Empid)
        {
            #region Linq Queries
            var mrNumber = from expDetailsAll in expDetailsDbContext.ExpenseDetails
                           join travelDetAll in expDetailsDbContext.TravelDetails
                           on expDetailsAll.MR_Number equals travelDetAll.MR_Number into EmpIdTable
                           from idnew1 in EmpIdTable.Where(id1=>id1.Id==Empid)
                           select new
                           {
                               newID = idnew1.MR_Number,
                           };
            #endregion
            foreach(var id in mrNumber)
            {
                if (id.newID == Empid)
                    MRNo = id.newID;
            }

            return MRNo;
        }

        public bool AddExpenseDetails(ExpenseDetail expenseDetail)
        {
            bool isExpAdded = false;
            try
            {
                expDetailsDbContext.ExpenseDetails.Add(expenseDetail);
                int i = expDetailsDbContext.SaveChanges();
                if (i > 0)
                    isExpAdded = true;
            }
            catch(ExpenseReportExceptionClass expDetailsObj)
            {
                throw expDetailsObj;
            }
            catch(Exception ex)
            {
                throw ex;
            }

            return isExpAdded;
        }

        
    }
}
