﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelManagementSystem.ExceptionClass;

namespace TravelManagementSystem.BussinessLayer
{
    public class ForgatePasswordOperations : EmployeeMasterBL
    {

        Training_24Oct18_PuneEntities empDbContext = null;
        public ForgatePasswordOperations()
        {
            empDbContext = new Training_24Oct18_PuneEntities();
        }
        public bool EmpUserIdExist(string usrId)
        {
            List<EmployeeMaster> empList = ListAllEmployees();
            bool isExists = false;
            try
            {
                #region Linq Querries
                //var modifiedEmpList = from Employee in empList.Where(usr => usr.UserId == usrId)
                //                      select new { Employee.Id, Employee.UserId };
                //foreach (var emp in modifiedEmpList)
                //{
                //    if (emp.UserId == usrId)
                //        isExists = true;
                //}
                var userIdExists = empDbContext.EmployeeMasters.SingleOrDefault(usr => usr.UserId == usrId);
                empDbContext.EmployeeMasters.Find(userIdExists.Id);
                isExists = true;
                #endregion
            }
            catch (EmployeeExceptionClass ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }

            return isExists;
        }

        public bool UpdatePassword(string usrID,string newPwd)
        {
            List<EmployeeMaster> empList = ListAllEmployees();
            bool isUpdated = false;
            try
            {
                #region Linq Querries
                //var updatePwd1 = from ObtainedPassword in empList.Where(usr => usr.UserId == usrID)
                //                select ObtainedPassword;
                
                var updatePwd = empDbContext.EmployeeMasters.SingleOrDefault(usr => usr.UserId == usrID);
                #endregion

                updatePwd.Password = newPwd;

                empDbContext.Entry(updatePwd).State = System.Data.Entity.EntityState.Modified;
                int i=empDbContext.SaveChanges();
                if (i > 0)
                    isUpdated = true;
            }
            catch(EmployeeExceptionClass ex)
            {
                throw ex;
            }
            catch(Exception e)
            {
                throw e;
            }
                          return isUpdated;
        }
    }
}
