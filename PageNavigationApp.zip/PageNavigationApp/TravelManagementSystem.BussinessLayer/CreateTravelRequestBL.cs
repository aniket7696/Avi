﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelManagementSystem.ExceptionClass;

namespace TravelManagementSystem.BussinessLayer
{
    public class CreateTravelRequestBL
    {
        Training_24Oct18_PuneEntities crtTravelDbContext = null;
        public CreateTravelRequestBL()
        {
            crtTravelDbContext = new Training_24Oct18_PuneEntities();
        }

        public bool AddTravelRequest(TravelDetail objTravelDetail)
        {
            bool isTravelAdded = false;
            try
            {
                crtTravelDbContext.TravelDetails.Add(objTravelDetail);
                int i = crtTravelDbContext.SaveChanges();
                if (i > 0)
                    isTravelAdded = true;
            }
            catch (TravelBookingExceptionClass travelObj)
            {
                throw travelObj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isTravelAdded;
        }
    }
}
