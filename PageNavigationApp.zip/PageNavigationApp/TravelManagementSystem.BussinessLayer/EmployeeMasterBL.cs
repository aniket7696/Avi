﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using TravelManagementSystem.ExceptionClass;

namespace TravelManagementSystem.BussinessLayer
{
    public class EmployeeMasterBL
    {
        Training_24Oct18_PuneEntities empDbContext = null;
        public static int obtEmpId;
        public EmployeeMasterBL()
        {
            empDbContext = new Training_24Oct18_PuneEntities();
        }

        //Logic for validitaions
        private static bool IsAllValid(EmployeeMaster employeeBL)
        {
            Regex reg = new Regex("/^[a-zA-Z]+$/");
           
            StringBuilder sbldr = new StringBuilder();
            bool validInfo = true;

          //  if (!reg.IsMatch(employeeBL.FirstName.ToString()))
           // {
           //     validInfo = false;
           //     sbldr.Append(Environment.NewLine + "First Name should contain Alphabets");
         //   }

            if (employeeBL.Mobile.Length < 10)
            {
                validInfo = false;
                sbldr.Append(Environment.NewLine + "Required 10 Digit Mobile Number");
            }

            if (employeeBL.Reimbursement_Account_No.Length < 16)
            {
                validInfo = false;
                sbldr.Append(Environment.NewLine + "Account Number should be of 16");
            }

            if (employeeBL.Password.Length < 8)
               if (employeeBL.Password.Length < 8)
              {
                validInfo = false;
                sbldr.Append(Environment.NewLine + "Must contain at least 8 or more characters");
            }

            if (validInfo == false)
            {
                throw new EmployeeExceptionClass(sbldr.ToString());
            }

            return validInfo;
        }

        public bool AddEmployee(EmployeeMaster employeeBL)
        {
            bool isAdd = false;
            try
            {
                if (IsAllValid(employeeBL))
                {
                    empDbContext.EmployeeMasters.Add(employeeBL);
                    int i = empDbContext.SaveChanges();
                    if (i > 0)
                        isAdd = true;
                }
            }
            catch (EmployeeExceptionClass travelObj)
            {
                throw travelObj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }

        public  List<EmployeeMaster> ListAllEmployees()
        {
            List<EmployeeMaster> employeeList = empDbContext.EmployeeMasters.ToList();
            return employeeList;
        }
        
        public int GetEmpId(string userId)
        {
            
            List<EmployeeMaster> empList = ListAllEmployees();

            foreach (var emp in empList)
            {
                if (emp.UserId == userId)
                    obtEmpId = emp.Id;
            }
            return obtEmpId;
        }
        public bool EmpExistLogin(string username,string pwd)
        {
            List<EmployeeMaster> empList = ListAllEmployees();
           
            foreach (var emp in empList)
            {
                if (emp.UserId == username && emp.Password == pwd)
                    return true;
            }
           
            return false;
        }

    }
}
