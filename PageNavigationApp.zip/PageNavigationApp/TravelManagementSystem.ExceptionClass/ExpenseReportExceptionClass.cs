﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelManagementSystem.ExceptionClass
{
    public class ExpenseReportExceptionClass:ApplicationException
    {
        //Default Contructor.
        public ExpenseReportExceptionClass() : base()
        { }

        //Parameterized Constructor.
        public ExpenseReportExceptionClass(string message) : base(message)
        { }

        //Parameterized constructor with two parameters.
        public ExpenseReportExceptionClass(string message, Exception innerException) : base(message, innerException)
        { }
    }
}
