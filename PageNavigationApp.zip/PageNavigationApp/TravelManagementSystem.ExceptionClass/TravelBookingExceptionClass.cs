﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelManagementSystem.ExceptionClass
{
    public class TravelBookingExceptionClass:ApplicationException
    {
        //Default Contructor.
        public TravelBookingExceptionClass() : base()
        { }

        //Parameterized Constructor.
        public TravelBookingExceptionClass(string message) : base(message)
        { }

        //Parameterized constructor with two parameters.
        public TravelBookingExceptionClass(string message, Exception innerException) : base(message, innerException)
        { }
    }
}
