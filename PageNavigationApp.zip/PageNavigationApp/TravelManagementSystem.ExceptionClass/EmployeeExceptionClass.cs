﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelManagementSystem.ExceptionClass
{
    public class EmployeeExceptionClass : ApplicationException
    {
        //Default Contructor.
        public EmployeeExceptionClass():base()
        { }

        //Parameterized Constructor.
        public EmployeeExceptionClass(string message) : base(message)
        { }

        //Parameterized constructor with two parameters.
        public EmployeeExceptionClass(string message, Exception innerException) : base(message,innerException)
        { }
    }
}
