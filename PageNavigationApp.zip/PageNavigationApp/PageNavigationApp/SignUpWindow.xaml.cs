﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelManagementSystem.ExceptionClass;
using TravelManagementSystem.BussinessLayer;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        //Object Declareation and initialization of Entity EmployeeMaster and BL EmployeeMasterBL class.
        EmployeeMaster employee = new EmployeeMaster();
        EmployeeMasterBL employeeBL = new EmployeeMasterBL();
       
        public SignUp()
        {
            InitializeComponent();
        }


        //Logic for validation
        private bool IsAllValid()
        {
            bool isEmpValid = true;
            StringBuilder sb = new StringBuilder(); //Initializing stringbuilder
                                                    //logic for all emp validation fields.
                                                    /* Validations for Null input */
            string usrPwd = txtPassword.Password;
            string cnfPwd = txtCnfPwd.Password;

            if (txtFirstName.Text == null | txtFirstName.Text == string.Empty | txtFirstName.Text.Length < 1)
                {
                    sb.Append(Environment.NewLine + "Please enter First Name!");
                   isEmpValid = false;
               }

            if (txtUserId.Text == null | txtUserId.Text == string.Empty | txtUserId.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter your User Id!");
                isEmpValid = false;
            }

            if (string.IsNullOrEmpty(usrPwd))
            {
                sb.Append(Environment.NewLine + "Please enter Password!");
                isEmpValid = false;
            }
            if (txtPassword.Password == null | txtUserId.Text == string.Empty | txtUserId.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter your User Id!");
                isEmpValid = false;
            }

            if (string.IsNullOrEmpty(usrPwd))
            {
                sb.Append(Environment.NewLine + "Please enter Confirm Password!");
                isEmpValid = false;
            }

            if (cmbLocation.Text == null | cmbLocation.Text == string.Empty | cmbLocation.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the Location!");
                isEmpValid = false;
            }

            if (txtMobNo.Text == null | txtMobNo.Text == string.Empty | txtMobNo.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the Mobile Number!");
                isEmpValid = false;
            }

            if (txtBankNo.Text == null | txtBankNo.Text == string.Empty | txtBankNo.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the Bank Account Number!");
                isEmpValid = false;
            }
            


            if (isEmpValid == false)
            {
                throw new EmployeeExceptionClass(sb.ToString());
            }
            return isEmpValid;
        }

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            
                
           
            try
            {
                string usrPwd = txtPassword.Password;
                string cnfPwd = txtCnfPwd.Password;
                if (IsAllValid()) //Checking if input is not null
                {
                    //Take input from user.
                    inputFromUser();
                bool status = employeeBL.AddEmployee(employee);

                    //code to authenticate user
                    if (status && IsAllValid() && (txtPassword.Password == txtCnfPwd.Password))
                    {
                        MessageBoxResult result = MessageBox.Show("Account Created!!!!", MessageBoxButton.OK.ToString());
                        if ((result == MessageBoxResult.OK))
                        {
                            this.Hide();
                            MainWindow mainWindow = new MainWindow();
                            mainWindow.Show();
                        }
                    }

                    else
                    {
                        MessageBox.Show("Password doesnot match!");
                    }

                
                }
                //this.Close();
            }
            catch(EmployeeExceptionClass empObj)
            {
                MessageBox.Show(empObj.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
   }

        //to clear all text of controls
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {

            foreach (UIElement control in gridSignUp.Children)
            {
                if (control.GetType() == typeof(TextBox))
                {
                    TextBox txtBox = (TextBox)control;

                    txtBox.Text = null;
                }
                if (control.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)control;

                    cmbBox.Text = null;
                }
            }
            
        }

        private void BtnAlreadyAcc_Click(object sender, RoutedEventArgs e)
        {
          //  this.Close();
            LoginWindow login = new LoginWindow();
            login.Show();
        }

        //take input from user
        private void inputFromUser()
        {
           
            employee.FirstName = txtFirstName.Text;
            employee.MiddleName = txtMiddName.Text;
            employee.LastName = txtLastName.Text;
            employee.UserId = txtUserId.Text;
            employee.Password = txtPassword.Password;
            employee.Location = cmbLocation.Text;
            employee.Mobile = txtMobNo.Text;
            employee.Reimbursement_Account_No = txtBankNo.Text;
            employee.Role = "Employee";
        }
    }
}
