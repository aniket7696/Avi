﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TravelManagementSystem.BussinessLayer;
using TravelManagementSystem.ExceptionClass;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for ExpenseReportPage.xaml
    /// </summary>
    public partial class ExpenseReportPage : Page
    {
        
        ExpenseDetail expenseDetail = null;
        ExpenseDetailsBL expenseBL = null;
        //EmployeeMasterBL employeeMasterBL = new EmployeeMasterBL();
        public ExpenseReportPage()
        {
            InitializeComponent();
            expenseDetail = new ExpenseDetail();
            expenseBL = new ExpenseDetailsBL();
            
        }


        //Logic for validation
        private bool IsAllValid()
        {
            bool isEmpValid = true;
            //logic for all emp validation fields.
            return isEmpValid;
        }

        //To clear all controls of page
        private void BtnClearReport_Click(object sender, RoutedEventArgs e)
        {
            foreach (UIElement control in grid.Children)
            {
                if (control.GetType() == typeof(TextBox))
                {
                    TextBox txtBox = (TextBox)control;

                    txtBox.Text = null;
                }
                if (control.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)control;

                    cmbBox.Text = null;
                }
                if (control.GetType() == typeof(DatePicker))
                {
                    DatePicker dpBox = (DatePicker)control;

                    dpBox.Text = null;
                }
            }
        }

        private void BtnCreateReport_Click(object sender, RoutedEventArgs e)
        {
            //Logic to add report.

            try
            {
               
                Input();
                bool status = expenseBL.AddExpenseDetails(expenseDetail);
                //code to authenticate user
                if (status)
                {
                    MessageBoxResult result = MessageBox.Show("Expense Report Created!!!!", MessageBoxButton.OK.ToString());
                    if ((result == MessageBoxResult.OK) && IsAllValid())
                    {

                        ExpenseReportView expenseReportView = new ExpenseReportView();
                        expenseReportView.Show();
                    }

                }
                
            }
            catch (EmployeeExceptionClass ex)
            {
                MessageBox.Show(ex.ToString());
            }
            catch (Exception exce)
            {
                MessageBox.Show(exce.ToString());
            }

        }

        private void Input()
        {
            expenseDetail.Expense_Date =Convert.ToDateTime(dpExpDate.Text);
            expenseDetail.Expense_Type = cmbExpType.Text;
            expenseDetail.Amount_Spent = Convert.ToDecimal(txtAmountSpent.Text);
            expenseDetail.Payment_Type = cmbPayMode.Text;
            expenseDetail.Reimbursement_Account_No = txtAccountNo.Text;
            int obtMrNo = expenseBL.MRNumberOfEmp(EmployeeMasterBL.obtEmpId);
            expenseDetail.MR_Number = obtMrNo;//retrive MR_Number from travel details table and 
                                              //Take input from user.
        }


    }
}
