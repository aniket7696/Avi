﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for ViewProfilePage.xaml
    /// </summary>
    public partial class ViewProfilePage : Page
    {
        public ViewProfilePage()
        {
            InitializeComponent();
        }

        //private void ClearAllText()
        //{
        //    foreach (UIElement control in gridTravelBooking.Children)
        //    {
        //        if (control.GetType() == typeof(TextBox))
        //        {
        //            TextBox txtBox = (TextBox)control;

        //            txtBox.Text = null;
        //        }
        //        if (control.GetType() == typeof(ComboBox))
        //        {
        //            ComboBox cmbBox = (ComboBox)control;

        //            cmbBox.Text = null;
        //        }
        //        if (control.GetType() == typeof(DatePicker))
        //        {
        //            DatePicker dpBox = (DatePicker)control;

        //            dpBox.Text = null;
        //        }
        //    }
        //}
    }
}
