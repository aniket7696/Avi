﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TravelManagementSystem.ExceptionClass;
using TravelManagementSystem.BussinessLayer;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for TravelBookingPage.xaml
    /// </summary>
    public partial class TravelBookingPage : Page
    {
        CreateTravelRequestBL crtTravelReq = null;
        TravelDetail objTravel = null;
        public TravelBookingPage()
        {
            InitializeComponent();
            crtTravelReq = new CreateTravelRequestBL();
            objTravel = new TravelDetail();
            txtEmpId.Text = Convert.ToString(EmployeeMasterBL.obtEmpId);
        }


        //Logic for validation
        private bool IsAllValid()
        {
            bool isEmpValid = true;
            StringBuilder sb = new StringBuilder(); //Initializing stringbuilder
                                                    //logic for all emp validation fields.
                                                    /* Validations for Null input */

            if (dpApplyDate.Text == null | dpApplyDate.Text == string.Empty | dpApplyDate.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter Date!");
                isEmpValid = false;
            }

            if (dpTravelDate.Text == null | dpTravelDate.Text == string.Empty | dpTravelDate.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter Apply Date!");
                isEmpValid = false;
            }

            if (cmbTravelMode.Text == null | cmbTravelMode.Text == string.Empty | cmbTravelMode.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the Mode of Travelling!");
                isEmpValid = false;
            }

            if (cmbFromCities.Text == null | cmbFromCities.Text == string.Empty | cmbFromCities.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the From City!");
                isEmpValid = false;
            }

            if (cmbToCity.Text == null | cmbToCity.Text == string.Empty | cmbToCity.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the ToCity!");
                isEmpValid = false;
            }

            if (txtTravelDuration.Text == null | txtTravelDuration.Text == string.Empty | txtTravelDuration.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the travelling duration!");
                isEmpValid = false;
            }

            if (isEmpValid == false)
            {
                throw new EmployeeExceptionClass(sb.ToString());
            }
            return isEmpValid;
        }


        //To clear all controls text.
        private void BtnClearBooking_Click(object sender, RoutedEventArgs e)
        {
            foreach (UIElement control in gridTravelBooking.Children)
            {
                if (control.GetType() == typeof(TextBox))
                {
                    TextBox txtBox = (TextBox)control;

                    txtBox.Text = null;
                }
                if (control.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)control;

                    cmbBox.Text = null;
                }
                if (control.GetType() == typeof(DatePicker))
                {
                    DatePicker dpBox = (DatePicker)control;

                    dpBox.Text = null;
                }
            }
        }

        private void BtnCreateBooking_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAllValid()) //Checking if input is not null
                {
                    InputFromUser();
                    bool status = crtTravelReq.AddTravelRequest(objTravel);
                    if (status && !(cmbFromCities.Text == cmbToCity.Text))
                    {
                        MessageBox.Show("Request Submitted Successfully!!");
                    }
                    else
                    {
                        MessageBox.Show("PickUp City and Drop City cannot be Same!!");
                    }
                }
            }
            catch (TravelBookingExceptionClass travelObj)
            {
                MessageBox.Show(travelObj.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void InputFromUser()
        {
            
            objTravel.Id = Convert.ToInt32(txtEmpId.Text);
            objTravel.Apply_date = Convert.ToDateTime(dpApplyDate.Text);
            objTravel.Reason_for_Travel = txtReasonForTravel.Text;
            objTravel.Travel_date = Convert.ToDateTime(dpTravelDate.Text);
            objTravel.Travel_Mode = cmbTravelMode.Text;
            objTravel.FromCity = cmbFromCities.Text;
            objTravel.ToCity = cmbToCity.Text;
            objTravel.Travel_duration = txtTravelDuration.Text;
        }
    }
}
