﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
             foreach (Control ctl in gridLoginMain.Children)
                {
                    if (ctl.GetType() == typeof(TextBox))
                        ((TextBox)ctl).Text = String.Empty;
                }
            
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtUserID.Text) && !string.IsNullOrEmpty(txtPassword.Password))
            {
                //code to authenticate user
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();

                //Call to the event
                RaiseLoginCompletedEvent();

            }
        }

        public event EventHandler LoginCompleted;
        private void RaiseLoginCompletedEvent()
        {
            var handler = LoginCompleted;
            if (handler != null)
                handler(this, EventArgs.Empty);
        }


    }
}
