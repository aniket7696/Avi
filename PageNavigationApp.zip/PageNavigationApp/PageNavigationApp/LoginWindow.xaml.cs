﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelManagementSystem.BussinessLayer;
using TravelManagementSystem.ExceptionClass;

namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        EmployeeMasterBL empBL = new EmployeeMasterBL();
       
        public LoginWindow()
        {
            InitializeComponent();
            
        }

        private bool IsAllValid()
        {
            bool isEmpValid = true;
            StringBuilder sb = new StringBuilder(); //Initializing stringbuilder
                                                    //logic for all emp validation fields.
                                                    /* Validations for Null input */
           string usrPwd = txtPassword.Password;

            if (txtUserID.Text == null | txtUserID.Text == string.Empty | txtUserID.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter User Id!");
                isEmpValid = false;
            }

            

           if(string.IsNullOrEmpty(usrPwd))
            {
               sb.Append(Environment.NewLine + "Please enter Password!");
                isEmpValid = false;
            }
           



            if (isEmpValid == false)
            {
                throw new EmployeeExceptionClass(sb.ToString());
            }
            return isEmpValid;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            txtPassword.Clear();
            txtUserID.Text = string.Empty;
            
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsAllValid()) //Checking if input is not null
            {

                string usrName = txtUserID.Text;
                string usrPwd = txtPassword.Password;
               
                    if (!string.IsNullOrEmpty(usrName) && !string.IsNullOrEmpty(usrPwd))
                    {
                        //code to Check user exists in database or not.
                        if (empBL.EmpExistLogin(txtUserID.Text, txtPassword.Password))
                        {
                            empBL.GetEmpId(txtUserID.Text);
                            MessageBoxResult result = MessageBox.Show("Login Successful!!!!", MessageBoxButton.OK.ToString());
                            if (result == MessageBoxResult.OK)
                            {
                                this.Hide();
                                MainWindow mainWindow = new MainWindow();
                                mainWindow.Show();

                            }
                        }
                        else
                            MessageBox.Show("Invalid Userid or Password");

                    }
                }
                }
            catch(EmployeeExceptionClass ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception excp)
            {
                MessageBox.Show(excp.Message);
            }
            this.Close();
        }

        private void BtnForgatePwd_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            ForgatePassword forgatePassword = new ForgatePassword();
            forgatePassword.Show();
            this.Close();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            SignUp signUp = new SignUp();
            signUp.Show();
            this.Close();
        }

    }
}
