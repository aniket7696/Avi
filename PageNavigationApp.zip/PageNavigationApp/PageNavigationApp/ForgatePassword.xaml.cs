﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravelManagementSystem.BussinessLayer;
using TravelManagementSystem.ExceptionClass;
namespace PageNavigationApp
{
    /// <summary>
    /// Interaction logic for ForgatePassword.xaml
    /// </summary>
    public partial class ForgatePassword : Window
    {
        ForgatePasswordOperations empForgatePassword = new ForgatePasswordOperations();
        public ForgatePassword()
        {
            InitializeComponent();
        }

        //Logic for validation
        private bool IsAllValid()
        {
            bool isEmpValid = true;
            //logic for all emp validation fields.
            return isEmpValid;
        }

        private void BtnUpdatePassword_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCnfPassword.Password) && !string.IsNullOrEmpty(txtNewPassword.Password))
            {
                //code to update password and linq querry.
                this.Hide();
                //code to authenticate user
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();

            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
           
                this.Hide();
                //code to authenticate user
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();

            
        }

        private void BtnVerifyUsrID_Click(object sender, RoutedEventArgs e)
        {
            string usrId = txtCnfUsrId.Text;
            string newPwd = txtNewPassword.Password;
            try
            {
                if (empForgatePassword.EmpUserIdExist(usrId))
                {

                    stkFrgPwdScreen.Visibility = Visibility.Visible;
                    //write logic to retrive userid of that employee id)
                    bool updated = empForgatePassword.UpdatePassword(usrId, newPwd);
                    if (updated)
                    {
                        MessageBoxResult result = MessageBox.Show("Password Updated Successfully !!!!!");
                        if ((result == MessageBoxResult.OK) && IsAllValid() && (txtNewPassword.Password == txtCnfPassword.Password))
                        {
                            this.Hide();
                            MainWindow mainWindow = new MainWindow();
                            mainWindow.Show();
                        }
                    }
                }
                else
                    stkFrgPwdScreen.Visibility = Visibility.Hidden;
            }
            catch (EmployeeExceptionClass empObj)
            {
                MessageBox.Show(empObj.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
